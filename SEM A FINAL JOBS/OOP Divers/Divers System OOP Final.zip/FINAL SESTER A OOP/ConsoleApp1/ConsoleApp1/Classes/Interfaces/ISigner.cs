interface ISigner
{
    public Signature Sign(); // :)
}