interface IDiveable
{
    public void Dive();
    public void GetOutFromWater();
}