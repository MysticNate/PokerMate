# Diff Summary

Date : 2025-02-17 00:25:24

Directory c:\\Users\\Giora\\OneDrive\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1

Total : 60 files,  730 codes, 34 comments, 61 blanks, all 825 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 51 | 419 | 34 | 56 | 509 |
| JSON | 5 | 267 | 0 | 0 | 267 |
| XML | 3 | 29 | 0 | 4 | 33 |
| Properties | 1 | 15 | 0 | 1 | 16 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 60 | 730 | 34 | 61 | 825 |
| . (Files) | 2 | 119 | 34 | 26 | 179 |
| .. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\.. | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1 | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1 | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes | 23 | -1,849 | -196 | -164 | -2,209 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CHumans | 4 | -345 | -38 | -45 | -428 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CLocations | 4 | -307 | -17 | -22 | -346 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CMisc | 3 | -146 | -14 | -11 | -171 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CUtility | 9 | -1,037 | -123 | -86 | -1,246 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CUtility (Files) | 5 | -311 | -35 | -24 | -370 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\CUtility\\General Utility | 4 | -726 | -88 | -62 | -876 |
| ..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\giorasmacbook\\Library\\CloudStorage\\OneDrive-Personal\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1\\Classes\\Interfaces | 3 | -14 | -4 | 0 | -18 |
| Classes | 24 | 2,141 | 185 | 191 | 2,517 |
| Classes\\CHumans | 4 | 354 | 39 | 43 | 436 |
| Classes\\CLocations | 4 | 309 | 18 | 21 | 348 |
| Classes\\CMisc | 3 | 162 | 15 | 13 | 190 |
| Classes\\CUtility | 10 | 1,302 | 109 | 114 | 1,525 |
| Classes\\CUtility (Files) | 5 | 311 | 35 | 24 | 370 |
| Classes\\CUtility\\General Utility | 5 | 991 | 74 | 90 | 1,155 |
| Classes\\Interfaces | 3 | 14 | 4 | 0 | 18 |
| bin | 2 | 53 | 0 | 0 | 53 |
| bin\\Debug | 2 | 53 | 0 | 0 | 53 |
| bin\\Debug\\net9.0 | 2 | 53 | 0 | 0 | 53 |
| obj | 9 | 266 | 11 | 8 | 285 |
| obj (Files) | 4 | 231 | 0 | 0 | 231 |
| obj\\Debug | 5 | 35 | 11 | 8 | 54 |
| obj\\Debug\\net9.0 | 5 | 35 | 11 | 8 | 54 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)