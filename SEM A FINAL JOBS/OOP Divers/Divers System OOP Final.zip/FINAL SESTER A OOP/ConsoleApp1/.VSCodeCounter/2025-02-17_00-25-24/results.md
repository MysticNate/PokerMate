# Summary

Date : 2025-02-17 00:25:24

Directory c:\\Users\\Giora\\OneDrive\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1

Total : 37 files,  2579 codes, 230 comments, 225 blanks, all 3034 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 28 | 2,268 | 230 | 220 | 2,718 |
| JSON | 5 | 267 | 0 | 0 | 267 |
| XML | 3 | 29 | 0 | 4 | 33 |
| Properties | 1 | 15 | 0 | 1 | 16 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 37 | 2,579 | 230 | 225 | 3,034 |
| . (Files) | 2 | 119 | 34 | 26 | 179 |
| Classes | 24 | 2,141 | 185 | 191 | 2,517 |
| Classes\\CHumans | 4 | 354 | 39 | 43 | 436 |
| Classes\\CLocations | 4 | 309 | 18 | 21 | 348 |
| Classes\\CMisc | 3 | 162 | 15 | 13 | 190 |
| Classes\\CUtility | 10 | 1,302 | 109 | 114 | 1,525 |
| Classes\\CUtility (Files) | 5 | 311 | 35 | 24 | 370 |
| Classes\\CUtility\\General Utility | 5 | 991 | 74 | 90 | 1,155 |
| Classes\\Interfaces | 3 | 14 | 4 | 0 | 18 |
| bin | 2 | 53 | 0 | 0 | 53 |
| bin\\Debug | 2 | 53 | 0 | 0 | 53 |
| bin\\Debug\\net9.0 | 2 | 53 | 0 | 0 | 53 |
| obj | 9 | 266 | 11 | 8 | 285 |
| obj (Files) | 4 | 231 | 0 | 0 | 231 |
| obj\\Debug | 5 | 35 | 11 | 8 | 54 |
| obj\\Debug\\net9.0 | 5 | 35 | 11 | 8 | 54 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)