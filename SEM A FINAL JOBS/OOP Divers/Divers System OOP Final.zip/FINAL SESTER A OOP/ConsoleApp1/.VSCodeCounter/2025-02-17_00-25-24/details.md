# Details

Date : 2025-02-17 00:25:24

Directory c:\\Users\\Giora\\OneDrive\\MyLife\\Giora\\לימודים\\הנדסאים\\שנה ב\\A FINAL PROJECT\\PokerMate\\SEM A FINAL JOBS\\OOP Divers\\FINAL SESTER A OOP\\ConsoleApp1\\ConsoleApp1

Total : 37 files,  2579 codes, 230 comments, 225 blanks, all 3034 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [ConsoleApp1/Classes/CHumans/Diver.cs](/ConsoleApp1/Classes/CHumans/Diver.cs) | C# | 137 | 17 | 9 | 163 |
| [ConsoleApp1/Classes/CHumans/DiverInstructor.cs](/ConsoleApp1/Classes/CHumans/DiverInstructor.cs) | C# | 44 | 7 | 5 | 56 |
| [ConsoleApp1/Classes/CHumans/Person.cs](/ConsoleApp1/Classes/CHumans/Person.cs) | C# | 134 | 10 | 26 | 170 |
| [ConsoleApp1/Classes/CHumans/User.cs](/ConsoleApp1/Classes/CHumans/User.cs) | C# | 39 | 5 | 3 | 47 |
| [ConsoleApp1/Classes/CLocations/Address.cs](/ConsoleApp1/Classes/CLocations/Address.cs) | C# | 67 | 3 | 2 | 72 |
| [ConsoleApp1/Classes/CLocations/Country.cs](/ConsoleApp1/Classes/CLocations/Country.cs) | C# | 37 | 3 | 5 | 45 |
| [ConsoleApp1/Classes/CLocations/DivingClub.cs](/ConsoleApp1/Classes/CLocations/DivingClub.cs) | C# | 138 | 8 | 10 | 156 |
| [ConsoleApp1/Classes/CLocations/DivingSite.cs](/ConsoleApp1/Classes/CLocations/DivingSite.cs) | C# | 67 | 4 | 4 | 75 |
| [ConsoleApp1/Classes/CMisc/DiveRank.cs](/ConsoleApp1/Classes/CMisc/DiveRank.cs) | C# | 51 | 5 | 6 | 62 |
| [ConsoleApp1/Classes/CMisc/DiveRankGiven.cs](/ConsoleApp1/Classes/CMisc/DiveRankGiven.cs) | C# | 46 | 5 | 4 | 55 |
| [ConsoleApp1/Classes/CMisc/Item.cs](/ConsoleApp1/Classes/CMisc/Item.cs) | C# | 65 | 5 | 3 | 73 |
| [ConsoleApp1/Classes/CUtility/DiveRegulation.cs](/ConsoleApp1/Classes/CUtility/DiveRegulation.cs) | C# | 49 | 7 | 4 | 60 |
| [ConsoleApp1/Classes/CUtility/DivingInfo.cs](/ConsoleApp1/Classes/CUtility/DivingInfo.cs) | C# | 161 | 14 | 8 | 183 |
| [ConsoleApp1/Classes/CUtility/General Utility/Color.cs](/ConsoleApp1/Classes/CUtility/General%20Utility/Color.cs) | C# | 67 | 3 | 0 | 70 |
| [ConsoleApp1/Classes/CUtility/General Utility/DB.cs](/ConsoleApp1/Classes/CUtility/General%20Utility/DB.cs) | C# | 80 | 5 | 2 | 87 |
| [ConsoleApp1/Classes/CUtility/General Utility/Helper.cs](/ConsoleApp1/Classes/CUtility/General%20Utility/Helper.cs) | C# | 79 | 7 | 11 | 97 |
| [ConsoleApp1/Classes/CUtility/General Utility/Printer.cs](/ConsoleApp1/Classes/CUtility/General%20Utility/Printer.cs) | C# | 493 | 27 | 35 | 555 |
| [ConsoleApp1/Classes/CUtility/General Utility/Validator.cs](/ConsoleApp1/Classes/CUtility/General%20Utility/Validator.cs) | C# | 272 | 32 | 42 | 346 |
| [ConsoleApp1/Classes/CUtility/Node.cs](/ConsoleApp1/Classes/CUtility/Node.cs) | C# | 80 | 9 | 8 | 97 |
| [ConsoleApp1/Classes/CUtility/Signature.cs](/ConsoleApp1/Classes/CUtility/Signature.cs) | C# | 11 | 0 | 2 | 13 |
| [ConsoleApp1/Classes/CUtility/WorkStamp.cs](/ConsoleApp1/Classes/CUtility/WorkStamp.cs) | C# | 10 | 5 | 2 | 17 |
| [ConsoleApp1/Classes/Interfaces/IBorrow.cs](/ConsoleApp1/Classes/Interfaces/IBorrow.cs) | C# | 5 | 4 | 0 | 9 |
| [ConsoleApp1/Classes/Interfaces/IDiveable.cs](/ConsoleApp1/Classes/Interfaces/IDiveable.cs) | C# | 5 | 0 | 0 | 5 |
| [ConsoleApp1/Classes/Interfaces/ISigner.cs](/ConsoleApp1/Classes/Interfaces/ISigner.cs) | C# | 4 | 0 | 0 | 4 |
| [ConsoleApp1/ConsoleApp1.csproj](/ConsoleApp1/ConsoleApp1.csproj) | XML | 11 | 0 | 4 | 15 |
| [ConsoleApp1/Program.cs](/ConsoleApp1/Program.cs) | C# | 108 | 34 | 22 | 164 |
| [ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.deps.json](/ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.deps.json) | JSON | 41 | 0 | 0 | 41 |
| [ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.runtimeconfig.json](/ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.runtimeconfig.json) | JSON | 12 | 0 | 0 | 12 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.dgspec.json](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.dgspec.json) | JSON | 80 | 0 | 0 | 80 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.props](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.props) | XML | 16 | 0 | 0 | 16 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.targets](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.targets) | XML | 2 | 0 | 0 | 2 |
| [ConsoleApp1/obj/Debug/net9.0/.NETCoreApp,Version=v9.0.AssemblyAttributes.cs](/ConsoleApp1/obj/Debug/net9.0/.NETCoreApp,Version=v9.0.AssemblyAttributes.cs) | C# | 3 | 1 | 1 | 5 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.AssemblyInfo.cs](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.AssemblyInfo.cs) | C# | 9 | 9 | 5 | 23 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GeneratedMSBuildEditorConfig.editorconfig](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GeneratedMSBuildEditorConfig.editorconfig) | Properties | 15 | 0 | 1 | 16 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GlobalUsings.g.cs](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GlobalUsings.g.cs) | C# | 7 | 1 | 1 | 9 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.sourcelink.json](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.sourcelink.json) | JSON | 1 | 0 | 0 | 1 |
| [ConsoleApp1/obj/project.assets.json](/ConsoleApp1/obj/project.assets.json) | JSON | 133 | 0 | 0 | 133 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)