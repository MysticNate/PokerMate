# Diff Summary

Date : 2025-02-12 19:00:25

Directory /Users/giorasmacbook/Library/CloudStorage/OneDrive-Personal/MyLife/Giora/לימודים/הנדסאים/שנה ב/A FINAL PROJECT/PokerMate/SEM A FINAL JOBS/OOP Divers/FINAL SESTER A OOP/ConsoleApp1/ConsoleApp1/Classes

Total : 13 files,  -339 codes, -27 comments, -18 blanks, all -384 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Properties | 1 | -15 | 0 | -1 | -16 |
| XML | 3 | -28 | 0 | -4 | -32 |
| C# | 4 | -44 | -27 | -13 | -84 |
| JSON | 5 | -252 | 0 | 0 | -252 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 13 | -339 | -27 | -18 | -384 |
| .. | 13 | -339 | -27 | -18 | -384 |
| .. (Files) | 2 | -36 | -16 | -10 | -62 |
| ../bin | 2 | -53 | 0 | 0 | -53 |
| ../bin/Debug | 2 | -53 | 0 | 0 | -53 |
| ../bin/Debug/net9.0 | 2 | -53 | 0 | 0 | -53 |
| ../obj | 9 | -250 | -11 | -8 | -269 |
| ../obj (Files) | 4 | -215 | 0 | 0 | -215 |
| ../obj/Debug | 5 | -35 | -11 | -8 | -54 |
| ../obj/Debug/net9.0 | 5 | -35 | -11 | -8 | -54 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)