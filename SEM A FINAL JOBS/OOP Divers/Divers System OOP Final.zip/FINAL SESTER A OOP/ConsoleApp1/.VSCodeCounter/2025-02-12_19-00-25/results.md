# Summary

Date : 2025-02-12 19:00:25

Directory /Users/giorasmacbook/Library/CloudStorage/OneDrive-Personal/MyLife/Giora/לימודים/הנדסאים/שנה ב/A FINAL PROJECT/PokerMate/SEM A FINAL JOBS/OOP Divers/FINAL SESTER A OOP/ConsoleApp1/ConsoleApp1/Classes

Total : 23 files,  1849 codes, 196 comments, 164 blanks, all 2209 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 23 | 1,849 | 196 | 164 | 2,209 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 23 | 1,849 | 196 | 164 | 2,209 |
| CHumans | 4 | 345 | 38 | 45 | 428 |
| CLocations | 4 | 307 | 17 | 22 | 346 |
| CMisc | 3 | 146 | 14 | 11 | 171 |
| CUtility | 9 | 1,037 | 123 | 86 | 1,246 |
| CUtility (Files) | 5 | 311 | 35 | 24 | 370 |
| CUtility/General Utility | 4 | 726 | 88 | 62 | 876 |
| Interfaces | 3 | 14 | 4 | 0 | 18 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)