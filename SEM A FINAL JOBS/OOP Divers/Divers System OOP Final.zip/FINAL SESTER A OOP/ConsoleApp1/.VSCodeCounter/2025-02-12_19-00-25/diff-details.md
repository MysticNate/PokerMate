# Diff Details

Date : 2025-02-12 19:00:25

Directory /Users/giorasmacbook/Library/CloudStorage/OneDrive-Personal/MyLife/Giora/לימודים/הנדסאים/שנה ב/A FINAL PROJECT/PokerMate/SEM A FINAL JOBS/OOP Divers/FINAL SESTER A OOP/ConsoleApp1/ConsoleApp1/Classes

Total : 13 files,  -339 codes, -27 comments, -18 blanks, all -384 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [ConsoleApp1/ConsoleApp1.csproj](/ConsoleApp1/ConsoleApp1.csproj) | XML | -11 | 0 | -4 | -15 |
| [ConsoleApp1/Program.cs](/ConsoleApp1/Program.cs) | C# | -25 | -16 | -6 | -47 |
| [ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.deps.json](/ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.deps.json) | JSON | -41 | 0 | 0 | -41 |
| [ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.runtimeconfig.json](/ConsoleApp1/bin/Debug/net9.0/ConsoleApp1.runtimeconfig.json) | JSON | -12 | 0 | 0 | -12 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.dgspec.json](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.dgspec.json) | JSON | -73 | 0 | 0 | -73 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.props](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.props) | XML | -15 | 0 | 0 | -15 |
| [ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.targets](/ConsoleApp1/obj/ConsoleApp1.csproj.nuget.g.targets) | XML | -2 | 0 | 0 | -2 |
| [ConsoleApp1/obj/Debug/net9.0/.NETCoreApp,Version=v9.0.AssemblyAttributes.cs](/ConsoleApp1/obj/Debug/net9.0/.NETCoreApp,Version=v9.0.AssemblyAttributes.cs) | C# | -3 | -1 | -1 | -5 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.AssemblyInfo.cs](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.AssemblyInfo.cs) | C# | -9 | -9 | -5 | -23 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GeneratedMSBuildEditorConfig.editorconfig](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GeneratedMSBuildEditorConfig.editorconfig) | Properties | -15 | 0 | -1 | -16 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GlobalUsings.g.cs](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.GlobalUsings.g.cs) | C# | -7 | -1 | -1 | -9 |
| [ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.sourcelink.json](/ConsoleApp1/obj/Debug/net9.0/ConsoleApp1.sourcelink.json) | JSON | -1 | 0 | 0 | -1 |
| [ConsoleApp1/obj/project.assets.json](/ConsoleApp1/obj/project.assets.json) | JSON | -125 | 0 | 0 | -125 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details