# Summary

Date : 2025-02-12 19:00:15

Directory /Users/giorasmacbook/Library/CloudStorage/OneDrive-Personal/MyLife/Giora/לימודים/הנדסאים/שנה ב/A FINAL PROJECT/PokerMate/SEM A FINAL JOBS/OOP Divers/FINAL SESTER A OOP/ConsoleApp1/ConsoleApp1

Total : 36 files,  2188 codes, 223 comments, 182 blanks, all 2593 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 27 | 1,893 | 223 | 177 | 2,293 |
| JSON | 5 | 252 | 0 | 0 | 252 |
| XML | 3 | 28 | 0 | 4 | 32 |
| Properties | 1 | 15 | 0 | 1 | 16 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 36 | 2,188 | 223 | 182 | 2,593 |
| . (Files) | 2 | 36 | 16 | 10 | 62 |
| Classes | 23 | 1,849 | 196 | 164 | 2,209 |
| Classes/CHumans | 4 | 345 | 38 | 45 | 428 |
| Classes/CLocations | 4 | 307 | 17 | 22 | 346 |
| Classes/CMisc | 3 | 146 | 14 | 11 | 171 |
| Classes/CUtility | 9 | 1,037 | 123 | 86 | 1,246 |
| Classes/CUtility (Files) | 5 | 311 | 35 | 24 | 370 |
| Classes/CUtility/General Utility | 4 | 726 | 88 | 62 | 876 |
| Classes/Interfaces | 3 | 14 | 4 | 0 | 18 |
| bin | 2 | 53 | 0 | 0 | 53 |
| bin/Debug | 2 | 53 | 0 | 0 | 53 |
| bin/Debug/net9.0 | 2 | 53 | 0 | 0 | 53 |
| obj | 9 | 250 | 11 | 8 | 269 |
| obj (Files) | 4 | 215 | 0 | 0 | 215 |
| obj/Debug | 5 | 35 | 11 | 8 | 54 |
| obj/Debug/net9.0 | 5 | 35 | 11 | 8 | 54 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)