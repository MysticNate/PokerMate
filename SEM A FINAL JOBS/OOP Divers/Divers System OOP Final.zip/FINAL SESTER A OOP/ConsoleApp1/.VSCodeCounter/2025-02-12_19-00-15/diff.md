# Diff Summary

Date : 2025-02-12 19:00:15

Directory /Users/giorasmacbook/Library/CloudStorage/OneDrive-Personal/MyLife/Giora/לימודים/הנדסאים/שנה ב/A FINAL PROJECT/PokerMate/SEM A FINAL JOBS/OOP Divers/FINAL SESTER A OOP/ConsoleApp1/ConsoleApp1

Total : 0 files,  0 codes, 0 comments, 0 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)